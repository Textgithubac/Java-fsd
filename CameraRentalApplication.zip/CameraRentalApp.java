package com.Simplilearn;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class Camera {
    private int id;
    private String brand;
    private String model;
    private double rentPerDay;
    private String status; // Available or Rented

    public Camera(int id, String brand, String model, double rentPerDay, String status) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.rentPerDay = rentPerDay;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentPerDay() {
        return rentPerDay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return String.format("%-4d %-10s %-10s %-10.2f %-10s", id, brand, model, rentPerDay, status);
    }
}

public class CameraRentalApp {
	private static Scanner scanner = new Scanner(System.in);
    private static List<Camera> cameraList = new ArrayList<>();
    private static int nextCameraId = 1;
    private static double walletBalance = 0;

    public static void main(String[] args) {
        System.out.println("WELCOME TO CAMERA RENTAL APP\nPLEASE LOGIN TO CONTINUE");

        System.out.print("USERNAME: ");
        String username = scanner.nextLine();
        System.out.print("PASSWORD: ");
        String password = scanner.nextLine();

        // Authenticate user
        if (authenticate(username, password)) {
            // Display main menu
            displayMainMenu();
        } else {
            System.out.println("Invalid username or password. Exiting...");
        }
    }
    private static boolean authenticate(String username, String password) {
        // Simple authentication logic for demonstration purposes
        return username.equals("admin") && password.equals("admin123");
    }

    private static boolean login(String username, String password) {
        // Actual authentication logic can be implemented here
        return username.equals("admin") && password.equals("admin123");
    }

    private static void displayMainMenu() {
        int choice;
        do {
            System.out.println("\n1. MY CAMERA");
            System.out.println("2. RENT A CAMERA");
            System.out.println("3. VIEW ALL CAMERAS");
            System.out.println("4. MY WALLET");
            System.out.println("5. EXIT");
            System.out.print("\nEnter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    handleMyCamera();
                    break;
                case 2:
                    rentCamera();
                    break;
                case 3:
                    viewAllCameras();
                    break;
                case 4:
                    viewWallet();
                    break;
                case 5:
                    System.out.println("Exiting application...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);
    }

    private static void handleMyCamera() {
        int choice;
        do {
            System.out.println("\n1. ADD");
            System.out.println("2. REMOVE");
            System.out.println("3. VIEW MY CAMERAS");
            System.out.println("4. GO TO PREVIOUS MENU");
            System.out.print("\nEnter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCamera();
                    break;
                case 2:
                    removeCamera();
                    break;
                case 3:
                    viewMyCameras();
                    break;
                case 4:
                    System.out.println("Going back to previous menu...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 4);
        System.out.println("======================================================");
    }
    

    private static void addCamera() {
        System.out.print("\nEnter the camera brand: ");
        String brand = scanner.next();
        System.out.print("Enter the model: ");
        String model = scanner.next();
        System.out.print("Enter the per day rent price (INR): ");
        double rentPerDay = scanner.nextDouble();

        cameraList.add(new Camera(nextCameraId++, brand, model, rentPerDay, "Available"));
        System.out.println("Your camera has been successfully added to the list.");
    }

    private static void removeCamera() {
        System.out.println("\nCAMERAS:");
        displayCameraHeader();
        for (Camera camera : cameraList) {
            System.out.println(camera);
        }
        System.out.print("\nEnter the camera ID to remove: ");
        int idToRemove = scanner.nextInt();
        boolean removed = false;
        Iterator<Camera> iterator = cameraList.iterator();
        while (iterator.hasNext()) {
            Camera camera = iterator.next();
            if (camera.getId() == idToRemove) {
                iterator.remove();
                removed = true;
                System.out.println("Camera successfully removed from the list.");
                break;
            }
        }
        if (!removed) {
            System.out.println("Camera not found with ID: " + idToRemove);
        }
        System.out.println("==========================================================");
    }

    private static void viewMyCameras() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras added yet.");
        } else {
            System.out.println("\nYour cameras:");
            displayCameraHeader();
            for (Camera camera : cameraList) {
                System.out.println(camera);
            }
           
        }
        System.out.println("=======================================================");
    }

    private static void displayCameraHeader() {
    	System.out.println("========================================================");
        System.out.println("\nID   BRAND      MODEL      PRICE      STATUS");
        System.out.println("========================================================");
    }
    

    private static void viewAllCameras() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available at this moment.");
    }
        System.out.println("========================================================");
    }
    private static void viewWallet() {
        System.out.println("\nYour wallet balance: INR " + walletBalance);
        System.out.print("\nDO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET? (1.YES 2.NO) ");
        int depositChoice = scanner.nextInt();

        if (depositChoice == 1) {
            // Prompt user to enter the amount to deposit
            System.out.print("ENTER THE AMOUNT (INR): ");
            double depositAmount = scanner.nextDouble();

            // Update wallet balance
            walletBalance += depositAmount;
            System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE INR. " + walletBalance);
        }
        System.out.println("===================================================");
    }

    private static void rentCamera() {
    	 if (cameraList.isEmpty()) {
    	        System.out.println("No cameras available for rent at this moment.");
    	        return;
    	    }

    	    System.out.println("\nAvailable Cameras:");
    	    displayCameraHeader();
    	    for (Camera camera : cameraList) {
    	        if (camera.getStatus().equals("Available")) {
    	            System.out.println(camera);
    	        }
    	    }

    	    System.out.print("\nEnter the camera ID you want to rent: ");
    	    int cameraId = scanner.nextInt();
    	    
    	    Camera selectedCamera = null;
    	    for (Camera camera : cameraList) {
    	        if (camera.getId() == cameraId) {
    	            selectedCamera = camera;
    	            break;
    	        }
    	    }

    	    if (selectedCamera == null) {
    	        System.out.println("Camera not found with ID: " + cameraId);
    	        return;
    	    }

    	    System.out.println("\nRenting Camera: " + selectedCamera.getBrand() + " " + selectedCamera.getModel());

    	    // Check wallet balance
    	    System.out.println("Your current wallet balance is INR. " + walletBalance);
    	    if (walletBalance < selectedCamera.getRentPerDay()) {
    	        System.out.println("Insufficient balance. Please deposit money to your wallet.");
    	        return;
    	    }

    	    // Deduct amount from wallet
    	    walletBalance -= selectedCamera.getRentPerDay();
    	    System.out.println("Amount of INR. " + selectedCamera.getRentPerDay() + " has been deducted from your wallet.");

    	    // Update camera status
    	    selectedCamera.setStatus("Rented");
    	    System.out.println("Camera rented successfully.");
    	    System.out.println("==================================================");
    }
    
   
}
