package com.learning.Practice.Project;
import java.util.Stack;
public class Practice_Project8 {
	 public static void main(String[] args) {
	        // Create a stack
	        Stack<Integer> stack = new Stack<>();

	        // Insert elements into the stack
	        stack.push(5);
	        stack.push(10);
	        stack.push(20);
	        stack.push(30);

	        // Display the stack
	        System.out.println("Stack after insertion: " + stack);

	        // Remove elements from the stack
	        int removedElement = stack.pop();
	        System.out.println("Removed element: " + removedElement);
	        System.out.println("Stack after removal: " + stack);

	        // Peek at the top element without removing it
	        int topElement = stack.peek();
	        System.out.println("Top element: " + topElement);

	        // Check if the stack is empty
	        boolean isEmpty = stack.isEmpty();
	        System.out.println("Is stack empty? " + isEmpty);
	    }

}
