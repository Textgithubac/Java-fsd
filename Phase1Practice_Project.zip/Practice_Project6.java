package com.learning.Practice.Project;
class Node1 {
    int data;
    Node next;

    public Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    private Node head;

    public CircularLinkedList() {
        this.head = null;
    }

    
    public void insert(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            head = newNode;
            head.next = head; 
            return;
        }

        Node current = head;
        Node prev = null;

        
        do {
            prev = current;
            current = current.next;
            
            if (prev.data <= newData && newData <= current.data) {
                break;
            }
            
            if (prev.data > current.data && (newData < current.data || newData > prev.data)) {
                break;
            }
        } while (current != head);

        
        prev.next = newNode;
        newNode.next = current;
    }

    // Function to display the elements of the circular linked list
    public void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class Practice_Project6 {
	public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        list.insert(5);
        list.insert(10);
        list.insert(20);
        list.insert(25);

        System.out.println("Original list:");
        list.display();

        int newData = 15;
        list.insert(newData);
        System.out.println("List after inserting " + newData + ":");
        list.display();
    }

}
