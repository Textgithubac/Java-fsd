package com.learning.Practice.Project;

import java.util.Arrays;

public class Practice_Project2 {
	public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            throw new IllegalArgumentException("Array size must be greater than or equal to 4");
        }
        Arrays.sort(arr); // Sort the array in ascending order
        return arr[3]; // Access the fourth element (index 3)
    }

    public static void main(String[] args) {
        int[] arr = {7, 10, 4, 3, 20, 15};
        int fourthSmallest = findFourthSmallest(arr);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

}
