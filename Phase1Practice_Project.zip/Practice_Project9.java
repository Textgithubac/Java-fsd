package com.learning.Practice.Project;
import java.util.LinkedList;
import java.util.Queue;
public class Practice_Project9 {
	  public static void main(String[] args) {
	        // Create a queue
	        Queue<Integer> queue = new LinkedList<>();

	        // Enqueue elements into the queue
	        enqueue(queue, 10);
	        enqueue(queue, 20);
	        enqueue(queue, 30);
	        enqueue(queue, 40);

	        // Display the queue
	        System.out.println("Queue after enqueue: " + queue);

	        // Dequeue elements from the queue
	        dequeue(queue);
	        dequeue(queue);

	        // Display the queue after dequeue
	        System.out.println("Queue after dequeue: " + queue);

	        // Peek at the front element without removing it
	        int frontElement = peek(queue);
	        System.out.println("Front element: " + frontElement);

	        // Check if the queue is empty
	        boolean isEmpty = isEmpty(queue);
	        System.out.println("Is queue empty? " + isEmpty);
	    }

	    // Function to insert (enqueue) an element into the queue
	    public static void enqueue(Queue<Integer> queue, int element) {
	        queue.offer(element);
	    }

	    // Function to remove (dequeue) an element from the queue
	    public static void dequeue(Queue<Integer> queue) {
	        if (!queue.isEmpty()) {
	            queue.poll();
	        } else {
	            System.out.println("Queue is empty. Cannot dequeue.");
	        }
	    }

	    // Function to peek at the front element of the queue without removing it
	    public static int peek(Queue<Integer> queue) {
	        if (!queue.isEmpty()) {
	            return queue.peek();
	        } else {
	            System.out.println("Queue is empty. No front element.");
	            return -1;
	        }
	    }

	    // Function to check if the queue is empty
	    public static boolean isEmpty(Queue<Integer> queue) {
	        return queue.isEmpty();
	    }
}


