package com.learning.Practice.Project;
class Node2 {
    int data;
    Node2 prev;
    Node2 next;

    public Node2(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    private Node2 head;
    private Node2 tail;

    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    // Function to insert a new node at the end of the doubly linked list
    public void insert(int newData) {
        Node2 newNode = new Node2(newData);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Function to traverse the doubly linked list in forward direction
    public void forwardTraversal() {
        Node2 current = head;
        System.out.println("Forward Traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Function to traverse the doubly linked list in backward direction
    public void backwardTraversal() {
        Node2 current = tail;
        System.out.println("Backward Traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}
public class Practice_Project7 {
	 public static void main(String[] args) {
	        DoublyLinkedList list = new DoublyLinkedList();
	        list.insert(1);
	        list.insert(2);
	        list.insert(3);
	        list.insert(4);
	        list.insert(5);

	        list.forwardTraversal();
	        list.backwardTraversal();
	    }
	
}

