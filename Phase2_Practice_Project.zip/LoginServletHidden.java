package com.simplilearn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServletHidden
 */
@WebServlet("/LoginServletHidden")
public class LoginServletHidden extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServletHidden() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve or create a session
        HttpSession session = request.getSession(true);
        String sessionID = session.getId();

        // Check if this is the first time the session is being created
        boolean isNewSession = session.isNew();

        // Retrieve previous count or set it to 0 if it's a new session
        Integer count = (Integer) session.getAttribute("count");
        if (count == null) {
            count = 0;
        }

        // Increment the count for each visit
        count++;

        // Store the updated count in the session
        session.setAttribute("count", count);

        out.println("<html><head><title>Session Tracking with Hidden Form Fields</title></head><body>");
        out.println("<h1>Session ID: " + sessionID + "</h1>");
        out.println("<h2>Session is New: " + isNewSession + "</h2>");
        out.println("<h2>Number of Visits: " + count + "</h2>");
        out.println("</body></html>");
	}

}
