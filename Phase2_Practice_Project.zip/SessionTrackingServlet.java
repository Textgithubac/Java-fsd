package com.simplilearn;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionTrackingServlet
 */
@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTrackingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");

        // Create a new session or get the existing session
        HttpSession session = request.getSession();

        // Set the username attribute in the session
        session.setAttribute("username", username);

        // Create a cookie to store the session ID
        Cookie cookie = new Cookie("sessionId", session.getId());

        // Set the cookie's max age to 1 hour (3600 seconds)
        cookie.setMaxAge(3600);

        // Add the cookie to the response
        response.addCookie(cookie);

        // Redirect to the welcome page
        response.sendRedirect("welcome.html");
    }
	

}
