package com.learning.Practice.Phase1;

public class Practice_Project9 {
	  public static void main(String[] args) {

	        // Create an array
	        int[] numbers = {1, 2, 3, 4, 5};

	        // Access elements using index
	        System.out.println("First element: " + numbers[0]);  // Accessing the first element

	        // Modify elements using index
	        numbers[2] = 10;  // Modifying the third element
	        System.out.println("Modified array: ");
	        for (int number : numbers) {
	            System.out.print(number + " ");
	        }
	        System.out.println();

	        // Get the length of the array
	        int length = numbers.length;
	        System.out.println("Length of the array: " + length);

	        // Iterate through the array elements
	        System.out.println("Elements in the array:");
	        for (int number : numbers) {
	            System.out.print(number + " ");
	        }
	        System.out.println();
	    }
	

}
