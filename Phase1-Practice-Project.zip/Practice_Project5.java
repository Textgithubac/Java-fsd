package com.learning.Practice.Phase1;
import java.util.ArrayList;

import java.util.Collection;
import java.util.HashSet;
import java.util.Scanner;

public class Practice_Project5 {
	public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);

	    // Choose collection type
	    System.out.println("Choose collection type (1 - ArrayList, 2 - HashSet): ");
	    int choice = scanner.nextInt();
	    Collection<String> collection = chooseCollection(choice);

	    // User interaction loop
	    while (true) {
	      System.out.println("\nChoose operation \n1: Add \n2: Remove \n3: Contains \n4: Size \n5: Exit  ");
	      choice = scanner.nextInt();

	      switch (choice) {
	        case 1:
	          System.out.println("Enter element to add: ");
	          String element = scanner.next();
	          collection.add(element);
	          System.out.println("Element added!");
	          break;
	        case 2:
	          System.out.println("Enter element to remove: ");
	          element = scanner.next();
	          if (collection.remove(element)) {
	            System.out.println("Element removed!");
	          } else {
	            System.out.println("Element not found!");
	          }
	          break;
	        case 3:
	          System.out.println("Enter element to check: ");
	          element = scanner.next();
	          if (collection.contains(element)) {
	            System.out.println("Collection contains the element!");
	          } else {
	            System.out.println("Collection doesn't contain the element!");
	          }
	          break;
	        case 4:
	          System.out.println("Collection size: " + collection.size());
	          break;
	        case 5:
	          System.out.println("Exiting...");
	          scanner.close();
	          return;
	        default:
	          System.out.println("Invalid choice!");
	      }
	    }
	  }

	  private static Collection<String> chooseCollection(int choice) {
	    if (choice == 1) {
	      return new ArrayList<>();
	    } else if (choice == 2) {
	      return new HashSet<>();
	    } else {
	      System.out.println("Invalid collection type. Defaulting to ArrayList.");
	      return new ArrayList<>();
	    }
	  }
}
