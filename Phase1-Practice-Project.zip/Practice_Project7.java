package com.learning.Practice.Phase1;
class University {
	
    private int courseId;
    private static double courseFee;
    
    public void getDepartment() {
        
        // method local inner class
        class Department{
            
            // inner class method 
            public void computer(){
                
                double TutionFee=30000.00;
                
                int extraFee=5000;
                
                System.out.println("We are Learning Java");
                
                //accessing private variable of outer class University
                courseId=1001;
                
                System.out.println("Course Id for Java is:"+ courseId);
                
                //accessing the static variable of outer class
                courseFee=TutionFee+extraFee;
                
                System.out.println("CourseFee:"+ courseFee);
                
            }    
        }
        //creating instance of inner class in inside the method of outer class
        Department depart=new Department();
        
        //calling method of inner class
        depart.computer();
        
    }
}
public class Practice_Project7 {
	public static void main(String[] args) {
        //creating outer class instance
        University university=new University();
        
        //calling outer class method
        university.getDepartment();              
    }
}

	


