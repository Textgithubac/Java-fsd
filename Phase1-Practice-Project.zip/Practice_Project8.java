package com.learning.Practice.Phase1;

public class Practice_Project8 {
	public static void concat1(String s1)

    {

        s1 = s1 + "Programming";

    }
    // Concatenates to StringBuilder

    public static void concat2(StringBuilder s2)

    {

        s2.append(" Programming");

    }
 
    // Concatenates to StringBuffer

    public static void concat3(StringBuffer s3)

    {

        s3.append(" Programming");

    }
 

    // Method 4
    public static void main(String[] args)

    {

        // String 1

        String s1 = "Java";
        concat1(s1);
        // s1 is not changed

        System.out.println("String: " + s1);
        // String 1

        StringBuilder s2 = new StringBuilder("Java");
 
        concat2(s2);
 

        // s2 is changed

        System.out.println("StringBuilder: " + s2);
        // String 3
        StringBuffer s3 = new StringBuffer("Python");
        concat3(s3);
        // s3 is changed
        System.out.println("StringBuffer: " + s3);

    }
}
