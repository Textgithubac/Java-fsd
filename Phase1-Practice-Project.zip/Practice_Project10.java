package com.learning.Practice.Phase1;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Practice_Project10 {
	public static void main(String[] args) {
        // Define a regular expression pattern
        String regex = "[a-zA-Z]+\\d+"; // Pattern for matching alphabets followed by digits
        
        // Create a string to test against the regular expression
        String testString = "Java123";
        
        // Create a Pattern object
        Pattern pattern = Pattern.compile(regex);
        
        // Create a Matcher object
        Matcher matcher = pattern.matcher(testString);
        
        // Verify implementation by finding matches
        if (matcher.find()) {
            System.out.println("Pattern matched: " + matcher.group());
        } else {
            System.out.println("Pattern not matched.");
        }
    }
	

}
