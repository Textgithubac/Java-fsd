package com.learning.Practice.Phase1;
class AccessModifierExample {
    // Public variable accessible everywhere
    public int publicVar = 20;

    // Default (package-private) variable accessible within the same package
    int defaultVar = 30;

    // Private variable accessible only within this class
    private int privateVar = 40;

    // Protected variable accessible within the same package and subclasses
    protected int protectedVar = 50;

    // Public method accessible everywhere
    public void publicMethod() {
        System.out.println("Public Method");
    }

    // Default (package-private) method accessible within the same package
    void defaultMethod() {
        System.out.println("Default Method");
    }

    // Private method accessible only within this class
    private void privateMethod() {
        System.out.println("Private Method");
    }

    // Protected method accessible within the same package and subclasses
    protected void protectedMethod() {
        System.out.println("Protected Method");
    }
}
public class Practice_Project2 {
	 public static void main(String[] args) {
	        AccessModifierExample obj = new AccessModifierExample();

	        // Accessing public variable and method
	        System.out.println("Public Variable: " + obj.publicVar);
	        obj.publicMethod();

	        // Accessing default (package-private) variable and method
	        System.out.println("Default Variable: " + obj.defaultVar);
	        obj.defaultMethod();

	        //to access private variable and method (will cause compilation error)
	        // System.out.println("Private Variable: " + obj.privateVar); // Compilation error
	        // obj.privateMethod(); // Compilation error

	        // Accessing protected variable and method (within the same package)
	        System.out.println("Protected Variable: " + obj.protectedVar);
	        obj.protectedMethod();
	    }
	

}
