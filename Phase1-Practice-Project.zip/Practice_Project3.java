package com.learning.Practice.Phase1;

public class Practice_Project3 {
	 public static int add(int a, int b) {
	        return a + b;
	    }

	    // Method to display a message
	    public static void displayMessage(String message) {
	        System.out.println(message);
	    }

	    // Method to calculate the factorial of a number recursively
	    public static int factorial(int n) {
	        if (n == 0 || n == 1) {
	            return 1;
	        } else {
	            return n * factorial(n - 1);
	        }
	    }

	    public static void main(String[] args) {
	        // Calling methods using different approaches
	        
	        // 1. Direct method call with arguments
	        int sum = add(5, 3);
	        System.out.println("Sum: " + sum);

	        // 2. Storing the result of method call in a variable
	        String message = "Hello, World!";
	        displayMessage(message);

	        // 3. Using method call as an argument to another method
	        displayMessage("Factorial of 5 is: " + factorial(5));

	        // 4. Method call inside a loop
	        for (int i = 1; i <= 5; i++) {
	            System.out.println("Factorial of " + i + " is: " + factorial(i));
	        }
	    }

}
