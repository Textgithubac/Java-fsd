package com.learning.Practice.Phase1;

public class Practice_Project4 {
	 private int value;

	    // Default constructor
	    public Practice_Project4() {
	        value = 0;
	    }

	    // Parameterized constructor
	    public Practice_Project4(int val) {
	        value = val;
	    }

	    // Copy constructor
	    public Practice_Project4(Practice_Project4 obj) {
	        value = obj.value;
	    }

	    // Display method
	    public void display() {
	        System.out.println(" Value = " + value);
	    }

	    public static void main(String[] args) {
	        // Creating objects using different constructors
	    	Practice_Project4 obj1 = new Practice_Project4(); // Default constructor
	    	Practice_Project4 obj2 = new Practice_Project4(10); // Parameterized constructor
	    	Practice_Project4 obj3 = new Practice_Project4(obj2); // Copy constructor

	        // Displaying values
	        System.out.print(" Object 1:");
	        obj1.display();
	        System.out.print(" Object 2:");
	        obj2.display();
	        System.out.print(" Object 3:");
	        obj3.display();
	    }
	

}
