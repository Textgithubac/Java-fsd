package com.learning.Practice.Phase1;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;
public class Practice_Project6 {
	public static void main(String[] args) {

		HashMap<Integer,String> nm=new HashMap<Integer,String>();      
	      nm.put(1,"Mango");    
	      nm.put(2,"Kiwi");    
	      nm.put(3,"Watermelon");   
	      System.out.println("\nThe elements of Hashmap are: ");  
	      for(Map.Entry x:nm.entrySet()){    
	       System.out.println(x.getKey()+" "+x.getValue());    
	      }
	    Hashtable<Integer,String> h = new Hashtable<Integer,String>();      
	      h.put(4,"banna");    
	      h.put(5,"Apple");    
	      h.put(6,"Orange");   
	      System.out.println("\nThe elements of Hashtable are: ");  
	      for(Map.Entry n:h.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
	    TreeMap<Integer,String> ma=new TreeMap<Integer,String>(); 
	      ma.put(7,"Plum");    
	      ma.put(8,"Cherry");    
	      ma.put(9,"Papaya");       
	      
	      System.out.println("\nThe elements of TreeMap are: ");  
	      for(Map.Entry l:ma.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    


	   
	   
	      



	
	}
	

}
