package com.learning.Practice.Phase1;


public class Practice_Project1 {
	  public static void main(String[] args) {
	        // Implicit type casting 
	        int intValue = 100;
	        long longValue = intValue; // Implicitly casting int to long
	        float floatValue = longValue; // Implicitly casting long to float
	        double doubleValue = floatValue; // Implicitly casting float to double
	        
	        // Displaying the values after implicit type casting
	        System.out.println("Implicit Type Casting:");
	        System.out.println("Int Value: " + intValue);
	        System.out.println("Long Value: " + longValue);
	        System.out.println("Float Value: " + floatValue);
	        System.out.println("Double Value: " + doubleValue);
	        
	        // Explicit type casting 
	        double bigValue = 1234.56;
	        float floatValue2 = (float) bigValue; // Explicitly casting double to float
	        long longValue2 = (long) floatValue2; // Explicitly casting float to long
	        int intValue2 = (int) longValue2; // Explicitly casting long to int
	        
	        // Displaying the values after explicit type casting
	        System.out.println("\nExplicit Type Casting:");
	        System.out.println("Double Value: " + bigValue);
	        System.out.println("Float Value: " + floatValue2);
	        System.out.println("Long Value: " + longValue2);
	        System.out.println("Int Value: " + intValue2);
	    }
	
}
