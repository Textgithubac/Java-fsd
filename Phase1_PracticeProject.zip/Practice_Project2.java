package com.learning.Simplilearn;

public class Practice_Project2 {
	private static Object o = new Object();
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Thread going to sleep");
		Thread.sleep(1000);
		System.out.println("Thread woke up after 1 second");
		
		synchronized(o) {
			System.out.println("Thread will wait for timeout.");
			o.wait(1000);
			
		}
		System.out.println("Thread will wake up after for timeout.");
		
		}

}
