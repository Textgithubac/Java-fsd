package com.learning.Simplilearn;
interface Animal {
    void eat();
}

interface Mammal extends Animal {
    void sleep();
}

interface Bird extends Animal {
    void fly();
}

// class implementing both Mammal and Bird interfaces
class Bat implements Mammal, Bird {
    @Override
    public void eat() {
        System.out.println("Bat eats insects.");
    }

    @Override
    public void sleep() {
        System.out.println("Bat sleeps during the day.");
    }

    @Override
    public void fly() {
        System.out.println("Bat flies at night.");
    }
}

public class Practice_Project9 {

	public static void main(String[] args) {
		Bat bat = new Bat();
        bat.eat();
        bat.sleep();
        bat.fly();
		

	}

}
