package com.learning.Simplilearn;
class InsufficientFundsException extends Exception {
	  public InsufficientFundsException(String message) {
	    super(message);
	  }
	}

	class Account {
	  private double balance;

	  public Account(double balance) {
	    this.balance = balance;
	  }

	  public void withdraw(double amount) throws InsufficientFundsException {
	    if (amount > balance) {
	      throw new InsufficientFundsException("Insufficient balance");
	    }
	    balance -= amount;
	  }

	  public double getBalance() {
	    return balance;
	  }
	}

public class Practice_Project5 {
	
	public static void main(String[] args) {
	    Account account = new Account(0);
	    try {
	      account.withdraw(50); // This will throw InsufficientFundsException
	    } catch (InsufficientFundsException e) {
	      System.out.println("Error: " + e.getMessage());
	    } finally {
	      System.out.println("Balance: " + account.getBalance()); // Always executes
	    }
	}
}
	
		 
