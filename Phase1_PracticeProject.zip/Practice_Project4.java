package com.learning.Simplilearn;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Practice_Project4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try 
		{
			System.out.println("Enter two numbers");
			int a = scanner.nextInt();
			int b = scanner.nextInt();
			
			int add = a+b;
			System.out.println("Addition of two numbers is: "+ add);
			
		}
		catch(InputMismatchException ex) 
		{
			System.out.println("Enter only the integer values");
			System.out.println(ex);
		}
		
		
	}
	

}
