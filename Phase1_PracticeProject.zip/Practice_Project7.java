package com.learning.Simplilearn;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class Practice_Project7 {
	public static void main(String[] args) {
        // Create a file
        createFile("test.txt");

        // Write data to the file
        writeFile("test.txt", "Hello, World!");

        // Read data from the file
        String data = readFile("test.txt");
        System.out.println("Data read from file: " + data);

        // Update data in the file
        updateFile("test.txt", "Updated content.");

        // Read updated data from the file
        String updatedData = readFile("test.txt");
        System.out.println("Updated data read from file: " + updatedData);

        // Delete the file
        deleteFile("test.txt");
        System.out.println("File deleted.");
    }

    // Method to create a file
    public static void createFile(String fileName) {
        File file = new File(fileName);
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }

    // Method to write data to a file
    public static void writeFile(String fileName, String data) {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(data);
            System.out.println("Data written to file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    // Method to read data from a file
    public static String readFile(String fileName) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file: " + e.getMessage());
        }
        return content.toString();
    }

    // Method to update data in a file
    public static void updateFile(String fileName, String newData) {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(newData);
            System.out.println("File updated.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file: " + e.getMessage());
        }
    }

    // Method to delete a file
    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("Deleted the file: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
    }

}
