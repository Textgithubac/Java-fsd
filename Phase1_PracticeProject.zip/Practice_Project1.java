package com.learning.Simplilearn;
class MyThread extends Thread {
    @Override
	public void run() {
        System.out.println("Thread created by extending Thread class.");
    }
}
class MyRunnable implements Runnable{
	@Override
	public void run() {
		System.out.println("Thread created by implementing Runnable interface");
		
	}

	
}
public class Practice_Project1 {
	public static void main(String[] args) {
        MyThread tr1 = new MyThread();
        tr1.start();
        Thread tr2 = new Thread(new MyRunnable());
        tr2.start();
        
    }

}
