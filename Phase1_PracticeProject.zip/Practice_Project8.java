package com.learning.Simplilearn;
class Car {
    private String brand;
    private String model;
    private int year;

    // Constructor
    public Car(String brand, String model, int year) {
        this.brand = brand;
        this.model = model;
        this.year = year;
    }

    // Getters and setters for encapsulation
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    // Abstraction: providing only essential information and hiding the details
    public void displayCarInfo() {
        System.out.println("Car: " + brand + " " + model + " " + year);
    }
}

// Inheritance: creating a new class based on an existing class
class ElectricCar extends Car {
    private int batteryCapacity;

    public ElectricCar(String brand, String model, int year, int batteryCapacity) {
        super(brand, model, year);
        this.batteryCapacity = batteryCapacity;
    }

    // Polymorphism-> the ability to take many forms
    @Override
    public void displayCarInfo() {
        super.displayCarInfo();
        System.out.println("Battery Capacity: " + batteryCapacity + " kWh");
    }
}

public class Practice_Project8 {
	 public static void main(String[] args) {
	        // Creating objects of Car and ElectricCar classes
	        Car car1 = new Car("Toyota ", "Camry ", 2022);
	        ElectricCar car2 = new ElectricCar("Tesla ", "Model S ", 2023, 100);

	        // Calling methods and demonstrating OOP pillars
	        car1.displayCarInfo(); // Encapsulation and abstraction
	        car2.displayCarInfo(); // Encapsulation, abstraction, inheritance, and polymorphism

	        // Changing object state through setters
	        car1.setYear(2024);
	        car1.displayCarInfo();
	    }

}
