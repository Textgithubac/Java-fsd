package com.example.servlet;

import java.io.IOException;
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction; 
import org.hibernate.cfg.Configuration;

import com.example.HibernateUtil;
import com.example.model.Product; 
/**
 * Servlet implementation class AddProductServlet
 */
@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SessionFactory sessionFactory;
	@Override
	public void init() throws ServletException { Configuration configuration = new Configuration().configure();
	sessionFactory = configuration.buildSessionFactory();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String name = request.getParameter("name");
	        String description = request.getParameter("description");
	        double price = Double.parseDouble(request.getParameter("price"));

	        // Create a new Product object
	        Product product = new Product(name, description, price);

	        // Save the product to the database
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            Transaction transaction = session.beginTransaction();
	            session.save(product);
	            transaction.commit();
	        } catch (Exception e) {
	            e.printStackTrace();
	            // Handle exception (e.g., show error message)
	            response.sendRedirect("error.jsp");
	            return;
	        }
	}

}
