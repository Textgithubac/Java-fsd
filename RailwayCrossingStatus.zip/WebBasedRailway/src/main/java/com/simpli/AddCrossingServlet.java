package com.simpli;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddCrossingServlet
 */
@WebServlet("/AddCrossingServlet")
public class AddCrossingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCrossingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String landmark = request.getParameter("landmark");
		String trainSchedules = request.getParameter("trainSchedules");
		String personInCharge = request.getParameter("personInCharge");
		String status = request.getParameter("status");
		// Create a new RailwayCrossing object with the form data
		RailwayCrossing crossing = new RailwayCrossing();
		crossing.setName(name);
		crossing.setAddress(address);
		crossing.setLandmark(landmark);
		crossing.setTrainSchedule(trainSchedules);
		crossing.setPersonInCharge(personInCharge);
		crossing.setStatus(status);
		// Save the new crossing to the database
		RailwayCrossingDAO crossingDAO = new RailwayCrossingDAO();
		crossingDAO.addCrossing(crossing);
		// Redirect to the admin homepage after adding the crossing
		response.sendRedirect("adminHome.jsp");
	}

}
